/*
 * File: stm32f4discovery_gettingstarted.c
 *
 * Code generated for Simulink model 'stm32f4discovery_gettingstarted'.
 *
 * Model version                  : 1.19
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Thu Mar  3 00:14:40 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "stm32f4discovery_gettingstarted.h"
#include "stm32f4discovery_gettingstarted_private.h"

/* Block states (default storage) */
DW_stm32f4discovery_gettingst_T stm32f4discovery_gettingstar_DW;

/* Real-time model */
RT_MODEL_stm32f4discovery_get_T stm32f4discovery_gettingstar_M_;
RT_MODEL_stm32f4discovery_get_T *const stm32f4discovery_gettingstar_M =
  &stm32f4discovery_gettingstar_M_;

/* Model step function */
void stm32f4discovery_gettingstarted_step(void)
{
  real_T rtb_PulseGenerator;

  /* DiscretePulseGenerator: '<Root>/Pulse Generator' */
  rtb_PulseGenerator = (stm32f4discovery_gettingstar_DW.clockTickCounter <
                        stm32f4discovery_gettingstart_P.PulseGenerator_Duty) &&
    (stm32f4discovery_gettingstar_DW.clockTickCounter >= 0) ?
    stm32f4discovery_gettingstart_P.PulseGenerator_Amp : 0.0;
  if (stm32f4discovery_gettingstar_DW.clockTickCounter >=
      stm32f4discovery_gettingstart_P.PulseGenerator_Period - 1.0) {
    stm32f4discovery_gettingstar_DW.clockTickCounter = 0;
  } else {
    stm32f4discovery_gettingstar_DW.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<Root>/Pulse Generator' */

  /* S-Function (stm32f4_do_write): '<Root>/LED4 (Green) (GPIOD, Pin 12, Pull-up, 50MHz)' incorporates:
   *  DataTypeConversion: '<Root>/Convert to logical'
   */
  MW_GPIO_WriteBit(3U, 12U, rtb_PulseGenerator != 0.0);
}

/* Model initialize function */
void stm32f4discovery_gettingstarted_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(stm32f4discovery_gettingstar_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&stm32f4discovery_gettingstar_DW, 0,
                sizeof(DW_stm32f4discovery_gettingst_T));

  /* Start for S-Function (stm32f4_do_write): '<Root>/LED4 (Green) (GPIOD, Pin 12, Pull-up, 50MHz)' */
  MW_GpioInit(3U, 4096U, 1U, 0U, 0U, 0U);

  /* InitializeConditions for DiscretePulseGenerator: '<Root>/Pulse Generator' */
  stm32f4discovery_gettingstar_DW.clockTickCounter = 0;
}

/* Model terminate function */
void stm32f4discovery_gettingstarted_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
